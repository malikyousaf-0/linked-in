// window.addEventListener("load", () => {
//   const url = window.location.href;
//   chrome.storage.local.get([url], (result) => {
//     const highlights = result[url] || [];
//     highlights.forEach(({ text }) => {
//       //   const range = document.createRange();
//       //   const frag = range.createContextualFragment(html);
//       //   document.body.appendChild(frag);
//       highlightText(text);
//     });
//   });
// });

// // Function to highlight the text
// function highlightText(text) {
//   console.log("highlightText");
//   console.log(text);
//   // Get the body of the document
//   const body = document.body;

//   // Create a range object
//   const range = document.createRange();

//   // Get all the text nodes in the document
//   const walker = document.createTreeWalker(
//     body,
//     NodeFilter.SHOW_TEXT,
//     null,
//     false
//   );

//   // Loop through the text nodes
//   while (walker.nextNode()) {
//     const node = walker.currentNode;
//     const nodeText = node.nodeValue;

//     // Find the index of the text in the current text node
//     const index = nodeText.indexOf(text);

//     if (index !== -1) {
//       // If the text is found, set the range
//       range.setStart(node, index);
//       range.setEnd(node, index + text.length);

//       // Create a span element to wrap the text
//       const span = document.createElement("span");
//       span.style.backgroundColor = "yellow"; // Highlight color
//       span.appendChild(range.extractContents());
//       range.insertNode(span);

//       // Stop after the first match
//       break;
//     }
//   }
// }

// // // Call the function with the specific text to highlight
// // highlightText(
// //   'With our "Try it Yourself" editor, you can edit Python code and view the result.'
// // );

// Function to highlight the text
function highlightText(text) {
  // Get the body of the document
  const body = document.body;

  // Create a range object
  const range = document.createRange();

  // Get all the text nodes in the document
  const walker = document.createTreeWalker(
    body,
    NodeFilter.SHOW_TEXT,
    null,
    false
  );

  // Loop through the text nodes
  while (walker.nextNode()) {
    const node = walker.currentNode;
    let nodeText = node.nodeValue;

    // While the text is found in the current node
    while (nodeText.includes(text)) {
      const index = nodeText.indexOf(text);

      // If the text is found, set the range
      range.setStart(node, index);
      range.setEnd(node, index + text.length);

      // Create a span element to wrap the text
      const span = document.createElement("span");
      span.style.backgroundColor = "yellow"; // Highlight color
      span.appendChild(range.extractContents());
      range.insertNode(span);

      // Move to the next part of the text node (after the highlighted part)
      nodeText = node.nodeValue;

      // Update the walker to the new current node
      walker.currentNode = span.nextSibling;
    }
  }
}

window.addEventListener("load", () => {
  const url = window.location.href;
  chrome.storage.local.get([url], (result) => {
    const highlights = result[url] || [];
    highlights.forEach(({ text }) => {
      highlightText(text);
    });
  });
});
