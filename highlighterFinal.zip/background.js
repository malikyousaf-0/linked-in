// chrome.runtime.onInstalled.addListener(() => {
//     chrome.contextMenus.create({
//       id: "highlightText",
//       title: "Highlight Selected Text",
//       contexts: ["selection"]
//     });
//   });
  
//   chrome.contextMenus.onClicked.addListener((info, tab) => {
//     if (info.menuItemId === "highlightText") {
//       chrome.scripting.executeScript({
//         target: { tabId: tab.id },
//         function: highlightSelectedText
//       });
//     }
//   });
  
//   function highlightSelectedText() {
//     const selection = window.getSelection();
//     if (!selection.rangeCount) return;
  
//     const range = selection.getRangeAt(0);
//     const span = document.createElement('span');
//     span.style.backgroundColor = 'yellow';
//     span.appendChild(range.extractContents());
//     range.insertNode(span);
  
//     selection.removeAllRanges();
//   }
      

chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
        id: "highlightText",
        title: "Highlight Selected Text",
        contexts: ["selection"]
    });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === "highlightText") {
        chrome.scripting.executeScript({
            target: { tabId: tab.id },
            function: highlightAndSaveText
        });
    }
});

function highlightAndSaveText() {
    const selection = window.getSelection();
    if (!selection.rangeCount) return;

    const range = selection.getRangeAt(0);
    const span = document.createElement('span');
    span.style.backgroundColor = 'yellow';
    span.appendChild(range.extractContents());
    range.insertNode(span);

    // Save the highlighted text and its range to storage
    const highlightedText = span.innerText;
    const url = window.location.href;

    chrome.storage.local.get([url], (result) => {
        const highlights = result[url] || [];
        highlights.push({ text: highlightedText, html: span.outerHTML });
        chrome.storage.local.set({ [url]: highlights });
    });

    selection.removeAllRanges();
}
