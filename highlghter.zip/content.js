window.addEventListener('load', () => {
    const url = window.location.href;
    chrome.storage.local.get([url], (result) => {
        const highlights = result[url] || [];
        highlights.forEach(({ html }) => {
            const range = document.createRange();
            const frag = range.createContextualFragment(html);
            document.body.appendChild(frag);
        });
    });
});
