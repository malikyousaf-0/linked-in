document.addEventListener('DOMContentLoaded', () => {
    const highlightsList = document.getElementById('highlightsList');

    chrome.storage.local.get(null, (items) => {
        for (const [url, highlights] of Object.entries(items)) {
            highlights.forEach(highlight => {
                const li = document.createElement('li');
                li.textContent = `${highlight.text} - ${url}`;
                highlightsList.appendChild(li);
            });
        }
    });
});
